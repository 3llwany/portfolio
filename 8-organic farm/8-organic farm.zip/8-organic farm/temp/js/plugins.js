/*global $*/


/*contener in slide show time change image */
$(document).ready(function () {
    "use strict";
    $('.carousel').carousel({
        interval: 5000
    });
});